﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.Models;

namespace FrontToBackP510.ViewModels
{
    public class HomeViewModel
    {
        public Slider Slider { get; set; }

        public List<SliderImage> SliderImages { get; set; }

        public List<Category> Categories { get; set; }

        //public List<Product> Products { get; set; }

        public About About { get; set; }

        public List<AboutPolicy> AboutPolicies { get; set; }

        public Blog Blog { get; set; }

        public List<BlogItem> BlogItems { get; set; }
    }
}
